import { createContext } from "react";

export const Ordersdatacontext = createContext({});
